(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/Desktop/Task-Manager/Task-Manager/node_modules/next/image.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/Documents/Desktop/Task-Manager/Task-Manager/node_modules/next/dist/shared/lib/image-external.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=6d05e_next_image_a1536ab6.js.map