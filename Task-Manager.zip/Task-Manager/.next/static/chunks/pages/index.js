__turbopack_load_page_chunks__("/", [
  "static/chunks/6d05e_next_dist_compiled_next-devtools_index_25f78849.js",
  "static/chunks/6d05e_next_dist_compiled_78c3f2d8._.js",
  "static/chunks/6d05e_next_dist_shared_lib_c1db0d1c._.js",
  "static/chunks/6d05e_next_dist_client_13a5c6da._.js",
  "static/chunks/6d05e_next_dist_9eea70eb._.js",
  "static/chunks/6d05e_next_image_a1536ab6.js",
  "static/chunks/6d05e_react-dom_24b0a0ac._.js",
  "static/chunks/6d05e_ab6e7d77._.js",
  "static/chunks/[root-of-the-server]__8ae6b679._.js",
  "static/chunks/Documents_Desktop_Task-Manager_Task-Manager_app_globals_2affa326.css",
  "static/chunks/Documents_Desktop_Task-Manager_Task-Manager_pages_index_2da965e7._.js",
  "static/chunks/turbopack-Documents_Desktop_Task-Manager_Task-Manager_pages_index_1323adbd._.js"
])
