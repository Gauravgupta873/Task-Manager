(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_785a1a8d._.js",
  "static/chunks/6d05e_next_dist_compiled_react-dom_631d557d._.js",
  "static/chunks/6d05e_next_dist_compiled_next-devtools_index_18c32056.js",
  "static/chunks/6d05e_next_dist_compiled_a0513381._.js",
  "static/chunks/6d05e_next_dist_client_d19ed592._.js",
  "static/chunks/6d05e_next_dist_9c33cc6d._.js",
  "static/chunks/6d05e_@swc_helpers_cjs_88555aab._.js"
],
    source: "entry"
});
