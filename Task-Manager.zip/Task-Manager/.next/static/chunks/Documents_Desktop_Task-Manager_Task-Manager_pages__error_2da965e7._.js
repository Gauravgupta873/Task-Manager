(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/6d05e_next_dist_compiled_next-devtools_index_25f78849.js",
  "static/chunks/6d05e_next_dist_compiled_3c61d25b._.js",
  "static/chunks/6d05e_next_dist_shared_lib_0556076a._.js",
  "static/chunks/6d05e_next_dist_client_67fa67ad._.js",
  "static/chunks/6d05e_next_dist_1abba535._.js",
  "static/chunks/6d05e_next_error_c47b92cf.js",
  "static/chunks/[next]_entry_page-loader_ts_e62c98f1._.js",
  "static/chunks/6d05e_react-dom_24b0a0ac._.js",
  "static/chunks/6d05e_5308cb3c._.js",
  "static/chunks/[root-of-the-server]__7aabfb0b._.js"
],
    source: "entry"
});
