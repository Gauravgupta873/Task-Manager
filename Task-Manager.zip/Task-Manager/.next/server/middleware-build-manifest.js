globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/6d05e_next_dist_compiled_next-devtools_index_25f78849.js",
      "static/chunks/6d05e_next_dist_compiled_78c3f2d8._.js",
      "static/chunks/6d05e_next_dist_shared_lib_c1db0d1c._.js",
      "static/chunks/6d05e_next_dist_client_13a5c6da._.js",
      "static/chunks/6d05e_next_dist_9eea70eb._.js",
      "static/chunks/6d05e_next_image_a1536ab6.js",
      "static/chunks/6d05e_react-dom_24b0a0ac._.js",
      "static/chunks/6d05e_ab6e7d77._.js",
      "static/chunks/[root-of-the-server]__8ae6b679._.js",
      "static/chunks/Documents_Desktop_Task-Manager_Task-Manager_app_globals_2affa326.css",
      "static/chunks/Documents_Desktop_Task-Manager_Task-Manager_pages_index_2da965e7._.js",
      "static/chunks/turbopack-Documents_Desktop_Task-Manager_Task-Manager_pages_index_1323adbd._.js"
    ],
    "/_app": [
      "static/chunks/6d05e_next_dist_compiled_next-devtools_index_25f78849.js",
      "static/chunks/6d05e_next_dist_compiled_3c61d25b._.js",
      "static/chunks/6d05e_next_dist_shared_lib_f79eebc8._.js",
      "static/chunks/6d05e_next_dist_client_67fa67ad._.js",
      "static/chunks/6d05e_next_dist_40dc2549._.js",
      "static/chunks/6d05e_next_app_237e9bc5.js",
      "static/chunks/[next]_entry_page-loader_ts_81318819._.js",
      "static/chunks/6d05e_react-dom_24b0a0ac._.js",
      "static/chunks/6d05e_5308cb3c._.js",
      "static/chunks/[root-of-the-server]__c5846486._.js",
      "static/chunks/Documents_Desktop_Task-Manager_Task-Manager_pages__app_2da965e7._.js",
      "static/chunks/turbopack-Documents_Desktop_Task-Manager_Task-Manager_pages__app_fa33b026._.js"
    ],
    "/_error": [
      "static/chunks/6d05e_next_dist_compiled_next-devtools_index_25f78849.js",
      "static/chunks/6d05e_next_dist_compiled_3c61d25b._.js",
      "static/chunks/6d05e_next_dist_shared_lib_0556076a._.js",
      "static/chunks/6d05e_next_dist_client_67fa67ad._.js",
      "static/chunks/6d05e_next_dist_1abba535._.js",
      "static/chunks/6d05e_next_error_c47b92cf.js",
      "static/chunks/[next]_entry_page-loader_ts_e62c98f1._.js",
      "static/chunks/6d05e_react-dom_24b0a0ac._.js",
      "static/chunks/6d05e_5308cb3c._.js",
      "static/chunks/[root-of-the-server]__7aabfb0b._.js",
      "static/chunks/Documents_Desktop_Task-Manager_Task-Manager_pages__error_2da965e7._.js",
      "static/chunks/turbopack-Documents_Desktop_Task-Manager_Task-Manager_pages__error_584323b5._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];