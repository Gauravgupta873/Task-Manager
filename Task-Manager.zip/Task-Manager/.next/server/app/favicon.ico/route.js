var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/6d05e_next_5543feab._.js")
R.c("server/chunks/[root-of-the-server]__2f6ffcec._.js")
R.m("[project]/Documents/Desktop/Task-Manager/Task-Manager/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/Documents/Desktop/Task-Manager/Task-Manager/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Documents/Desktop/Task-Manager/Task-Manager/app/favicon--route-entry.js [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)")
module.exports=R.m("[project]/Documents/Desktop/Task-Manager/Task-Manager/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Documents/Desktop/Task-Manager/Task-Manager/app/favicon--route-entry.js [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)").exports
