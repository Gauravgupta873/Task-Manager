var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/tasks.js")
R.c("server/chunks/6d05e_next_dist_9870f3a0._.js")
R.c("server/chunks/[root-of-the-server]__6278da68._.js")
R.m("[project]/Documents/Desktop/Task-Manager/Task-Manager/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/api/tasks.js [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/Documents/Desktop/Task-Manager/Task-Manager/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/api/tasks.js [api] (ecmascript)\" } [api] (ecmascript)").exports
