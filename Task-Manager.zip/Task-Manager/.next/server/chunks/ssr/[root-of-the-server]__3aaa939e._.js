module.exports = [
"[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react/jsx-dev-runtime", () => require("react/jsx-dev-runtime"));

module.exports = mod;
}),
"[externals]/react-dom [external] (react-dom, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-dom", () => require("react-dom"));

module.exports = mod;
}),
"[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Desktop$2f$Task$2d$Manager$2f$Task$2d$Manager$2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/Desktop/Task-Manager/Task-Manager/node_modules/next/image.js [ssr] (ecmascript)"); // Import Next.js Image component
;
;
;
;
function Home() {
    const [tasks, setTasks] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])([]); // Array to store tasks
    const [newTask, setNewTask] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(''); // Store new task title as string
    const [newDescription, setNewDescription] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(''); // Store new task description as string
    const [filter, setFilter] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])("all"); // Store the current selected filter for filter section
    const [activeTask, setActiveTask] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(null); // Store which task is selected by user to perform actions like delete task or other
    const [newTaskMenu, setNewTaskMenu] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false); // Store states of new task menu
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        fetchTasks();
    }, []);
    const fetchTasks = async ()=>{
        const res = await fetch('/api/tasks');
        const data = await res.json();
        setTasks(data);
    };
    const addTask = async ()=>{
        if (!newTask.trim()) return;
        await fetch('/api/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title: newTask,
                description: newDescription
            })
        });
        setNewTask('');
        setNewDescription('');
        fetchTasks();
    };
    const toggleTask = async (id, status)=>{
        await fetch(`/api/tasks?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: status
            })
        });
        fetchTasks();
    };
    const deleteTask = async (id)=>{
        await fetch(`/api/tasks?id=${id}`, {
            method: 'DELETE'
        });
        fetchTasks();
    };
    const filteredTasks = tasks.filter((task)=>{
        if (filter === 'all') return true;
        return task.status === filter;
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "bg-slate-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "grid grid-flow-col justify-between px-3 mb-4 pt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "text-black",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Desktop$2f$Task$2d$Manager$2f$Task$2d$Manager$2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            src: "/u3.jpg",
                            alt: "User Profile",
                            width: 60,
                            height: 60,
                            className: "rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                            lineNumber: 60,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                        lineNumber: 58,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        className: "text-white bg-black px-6 py-3 rounded-full text-2xl",
                        onClick: ()=>setNewTaskMenu(true),
                        children: "+"
                    }, void 0, false, {
                        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                        lineNumber: 62,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                lineNumber: 57,
                columnNumber: 13
            }, this),
            newTaskMenu && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black bg-opacity-70 backdrop-blur-md flex items-center justify-center z-40",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "bg-white w-3/4 max-w-md mx-auto rounded-lg p-6 text-center space-y-3 space-x-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                            className: "text-gray-700 text-2xl",
                            children: " Add New Task"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                            lineNumber: 70,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                            type: "text",
                            className: "border p-2 w-full bg-gray-50 border-gray-600 rounded-2xl placeholder:text-gray-400 text-gray-800",
                            placeholder: "Task Name",
                            value: newTask,
                            onChange: (e)=>setNewTask(e.target.value)
                        }, void 0, false, {
                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                            lineNumber: 71,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                            type: "text",
                            className: "border p-2 w-full bg-gray-50 border-gray-600 rounded-2xl placeholder:text-gray-400 text-gray-800",
                            placeholder: "Task Description",
                            value: newDescription,
                            onChange: (e)=>setNewDescription(e.target.value)
                        }, void 0, false, {
                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                            lineNumber: 78,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                            className: "bg-green-500 text-white w-1/2 mx-auto px-4 py-2 rounded-full",
                            onClick: addTask,
                            children: "Add Task"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                            lineNumber: 85,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                            className: "border-2 border-red-500 text-red-500 w-1/2 mx-auto px-4 py-2 rounded-full",
                            onClick: ()=>setNewTaskMenu(false),
                            children: "Close Task"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                            lineNumber: 91,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                    lineNumber: 69,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                lineNumber: 68,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "filter-section grid grid-flow-col px-3 space-x-2 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        className: `filter-btn px-4 py-2 text-xs text-gray-600 ${filter === 'all' ? 'border-2 border-gray-600 rounded-full text-gray-800' : 'border-2 border-gray-700 rounded-full text-gray-600'}`,
                        onClick: ()=>setFilter("all"),
                        children: "All"
                    }, void 0, false, {
                        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                        lineNumber: 102,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        className: `filter-btn px-4 py-2 text-xs text-gray-600 ${filter === 'done' ? 'border-2 border-gray-600 rounded-full text-gray-800' : 'border-2 border-gray-700 rounded-full text-gray-600'}`,
                        onClick: ()=>setFilter("done"),
                        children: "Done"
                    }, void 0, false, {
                        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                        lineNumber: 110,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        className: `filter-btn px-4 py-2 text-xs text-gray-600 ${filter === 'in-progress' ? 'border-2 border-gray-600 rounded-full text-gray-800' : 'border-2 border-gray-700 rounded-full text-gray-600'}`,
                        onClick: ()=>setFilter("in-progress"),
                        children: "In Progress"
                    }, void 0, false, {
                        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                        lineNumber: 118,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        className: `filter-btn px-4 py-2 text-xs text-gray-600 ${filter === 'under-review' ? 'border-2 border-gray-600 rounded-full text-gray-800' : 'border-2 border-gray-700 rounded-full text-gray-600'}`,
                        onClick: ()=>setFilter("under-review"),
                        children: "Under Review"
                    }, void 0, false, {
                        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                        lineNumber: 126,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                lineNumber: 101,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("ul", {
                className: "grid",
                children: filteredTasks.map((task)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("li", {
                        "data-status": task.status === "done" ? "done" : task.status === "under-review" ? "under-review" : "in-progress",
                        className: `relative grid grid-flow-row items-center mb-1 rounded-3xl text-lg
                        ${task.status === "done" ? `bg-green-500` : task.status === "under-review" ? `bg-slate-400` : `bg-cyan-600`} m-2 px-4 font-light `,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "col-span-2",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "mt-4 pb-4 text-gray-100",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    onClick: ()=>setActiveTask(task._id),
                                                    children: task.title
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                                    lineNumber: 145,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "text-xs mt-6",
                                                    children: task.description
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                                    lineNumber: 148,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                            lineNumber: 144,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                        lineNumber: 143,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "grid",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "text-center text-xs text-gray-50 border-2 border-gray-50 m-auto px-3 py-1 rounded-full",
                                            children: task.status === "done" ? "done" : task.status === "under-review" ? "under-review" : "In-progress"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                            lineNumber: 154,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                        lineNumber: 153,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                lineNumber: 142,
                                columnNumber: 25
                            }, this),
                            activeTask === task._id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "fixed inset-0 bg-gray-100 bg-opacity-95 flex flex-col justify-center items-center p-4 z-20",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "grid grid-flow-row space-y-2 text-base",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                            className: "bg-green-500 text-white px-4 py-2 rounded-full",
                                            onClick: ()=>{
                                                toggleTask(task._id, "done");
                                                setActiveTask(null);
                                            },
                                            children: "Mark as Done"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                            lineNumber: 163,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                            className: "bg-cyan-600 text-white px-4 py-2 rounded-full",
                                            onClick: ()=>{
                                                toggleTask(task._id, "in-progress");
                                                setActiveTask(null);
                                            },
                                            children: "Mark as In-Progress"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                            lineNumber: 172,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                            className: "bg-slate-400 text-white px-4 py-2 rounded-full",
                                            onClick: ()=>{
                                                toggleTask(task._id, "under-review");
                                                setActiveTask(null);
                                            },
                                            children: "Mark as Under-Review"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                            lineNumber: 181,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                            className: "border-2 border-red-500 text-red-500 px-4 py-2 rounded-full",
                                            onClick: ()=>{
                                                deleteTask(task._id);
                                                setActiveTask(null);
                                            },
                                            children: "Delete"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                            lineNumber: 190,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                            className: "border-2 border-gray-500 text-gray-500 px-4 py-2 rounded-full",
                                            onClick: ()=>{
                                                setActiveTask(null);
                                            },
                                            children: "Close"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                            lineNumber: 199,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                    lineNumber: 162,
                                    columnNumber: 33
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                                lineNumber: 161,
                                columnNumber: 29
                            }, this)
                        ]
                    }, task._id, true, {
                        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                        lineNumber: 138,
                        columnNumber: 21
                    }, this))
            }, void 0, false, {
                fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
                lineNumber: 136,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/index.js",
        lineNumber: 56,
        columnNumber: 9
    }, this);
}
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__3aaa939e._.js.map