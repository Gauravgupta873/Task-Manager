module.exports = [
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/mongoose [external] (mongoose, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mongoose", () => require("mongoose"));

module.exports = mod;
}),
"[project]/Documents/Desktop/Task-Manager/Task-Manager/lib/db.js [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "connectToDatabase",
    ()=>connectToDatabase
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const MONGO_URI = process.env.MONGO_URI;
let isConnected = false;
const connectToDatabase = async ()=>{
    if (isConnected) return;
    try {
        const db = await __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].connect(MONGO_URI); // Removed deprecated options
        isConnected = db.connection.readyState === 1;
        console.log("Connected to MongoDB");
    } catch (error) {
        console.error("MongoDB connection failed:", error.message);
        throw new Error("Failed to connect to MongoDB");
    }
};
}),
"[project]/Documents/Desktop/Task-Manager/Task-Manager/models/Task.js [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const TaskSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        default: "10.00 AM - 5.30 PM"
    },
    status: {
        type: String,
        default: "Under-Review"
    }
});
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].models.Task || __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].model("Task", TaskSchema);
}),
"[project]/Documents/Desktop/Task-Manager/Task-Manager/pages/api/tasks.js [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>handler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Desktop$2f$Task$2d$Manager$2f$Task$2d$Manager$2f$lib$2f$db$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/Desktop/Task-Manager/Task-Manager/lib/db.js [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Desktop$2f$Task$2d$Manager$2f$Task$2d$Manager$2f$models$2f$Task$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/Desktop/Task-Manager/Task-Manager/models/Task.js [api] (ecmascript)");
;
;
async function handler(req, res) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Desktop$2f$Task$2d$Manager$2f$Task$2d$Manager$2f$lib$2f$db$2e$js__$5b$api$5d$__$28$ecmascript$29$__["connectToDatabase"])();
    const { method } = req;
    const { id } = req.query;
    try {
        switch(method){
            case "GET":
                const tasks = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Desktop$2f$Task$2d$Manager$2f$Task$2d$Manager$2f$models$2f$Task$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].find({});
                res.status(200).json(tasks);
                break;
            case "POST":
                // Validate body
                if (!req.body.title || !req.body.description) {
                    return res.status(400).json({
                        message: "Title and description are required"
                    });
                }
                const newTask = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Desktop$2f$Task$2d$Manager$2f$Task$2d$Manager$2f$models$2f$Task$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].create(req.body);
                res.status(201).json(newTask);
                break;
            case "PUT":
                const updatedTask = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Desktop$2f$Task$2d$Manager$2f$Task$2d$Manager$2f$models$2f$Task$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].findByIdAndUpdate(id, req.body, {
                    new: true
                });
                if (!updatedTask) {
                    return res.status(404).json({
                        message: "Task not found"
                    });
                }
                res.status(200).json(updatedTask);
                break;
            case "DELETE":
                const deletedTask = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Desktop$2f$Task$2d$Manager$2f$Task$2d$Manager$2f$models$2f$Task$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].findByIdAndDelete(id);
                if (!deletedTask) {
                    return res.status(404).json({
                        message: "Task not found"
                    });
                }
                res.status(204).send();
                break;
            default:
                res.setHeader("Allow", [
                    "GET",
                    "POST",
                    "PUT",
                    "DELETE"
                ]);
                res.status(405).json({
                    message: `Method ${method} Not Allowed`
                });
                break;
        }
    } catch (error) {
        console.error("API Handler Error:", error.message);
        res.status(500).json({
            message: "Internal Server Error"
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__6278da68._.js.map